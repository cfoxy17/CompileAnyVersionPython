import os, glob, shutil, re, sys

def main():
	print("hello")
	
if __name__ == "__main__":
    sys.exit(main())	